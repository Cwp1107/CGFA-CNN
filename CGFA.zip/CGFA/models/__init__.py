from .DRCNN import DRCNN
from .VGG16 import vgg16
from .DRCNN_NetFV import CGFA_CNN_NetFV